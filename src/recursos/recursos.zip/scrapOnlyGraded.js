const puppeteer = require('puppeteer');

async function getData(url) {
    const browser = await puppeteer.launch({ headless: true });
    const page = await browser.newPage();

    try {
        await page.goto(url, { waitUntil: 'networkidle2' });

        // Obtener los datos generales como antes
        const data = await page.evaluate((pageUrl) => {
            const result = {
                certNumber: '',
                cardName: '',
                game: '',
                year: '',
                cardSet: '',
                cardNumber: '',
                grade: '',
                imageUrl: '',
                referencia: pageUrl,
                empresa: pageUrl.replace(/(https?:\/\/)?(www\.)?/, '').split('/')[0].replace(/\.com$/, '')
            };

            return result;
        }, page.url());

        // Obtener los datos de la tabla específica
        const tableData = await page.evaluate(() => {
            const tableData = {};
            const tableElement = document.querySelector('table.withdraw__table');

            if (tableElement) {
                const rows = tableElement.querySelectorAll('tbody tr');

                rows.forEach(row => {
                    const cells = row.querySelectorAll('td');
                    if (cells.length === 2) {
                        const key = cells[0].innerText.trim();
                        const value = cells[1].innerText.trim();
                        tableData[key] = value;
                    }
                });
            }

            return tableData;
        });

        // Combinar los datos generales con los datos de la tabla
        const finalData = { ...data, ...tableData };

        // Mostrar solo los datos específicos de la tabla
        printData(finalData);

    } catch (error) {
        console.error('Error:', error);

    } finally {
        await browser.close();
    }
}

function printData(data) {
    console.log('Nombre:', data['Name']);
    console.log('Codigo:', data['Certificate Number']);
    console.log('Numero:', 0);
    console.log('Anio:', data['Year']);
    console.log('Coleccion:', data['Brand']);
    console.log('Edicion:', data['Set Name']);
    console.log('Empresa:', data.empresa);
    console.log('Gradeo:', data['Condition'] + ' ' + data['Grade']);
    console.log('Referencia:', data.referencia);
}

// URL de prueba
const url = 'https://www.onlygraded.com/cert-verification.php?certcode=' + process.argv[2];

// Llamar a la función para obtener y mostrar los datos
getData(url);
