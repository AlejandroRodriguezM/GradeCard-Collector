const puppeteer = require('puppeteer');

async function waitForManualCaptchaSolution() {
    // Espera 2 segundos para que el usuario resuelva el CAPTCHA manualmente (puedes ajustar este tiempo)
    await new Promise(resolve => setTimeout(resolve, 2000));
}

async function getPageData(page) {
    const data = await page.evaluate(() => {
        const result = {
            empresa: '',
            direccionImagen: '',
            tabla: {},
            gradeo: '',
            nombre: '',
            anio: '',
            edicion: '',
            numero: '',
            codigo: ''
        };

        // Obtener la dirección de la imagen
        const imgElement = document.querySelector('img[title="Obverse"]');
        result.direccionImagen = imgElement ? imgElement.src : '';

        // Obtener datos de dl > dt y dd dentro de div.content-wrapper
        const contentWrapper = document.querySelector('div.content-wrapper');

        // Obtener datos de dl > dt y dd
        const dlElements = contentWrapper.querySelectorAll('dl');

        dlElements.forEach(dl => {
            const dtElement = dl.querySelector('dt');
            const ddElement = dl.querySelector('dd');
            if (dtElement && ddElement) {
                const dtText = dtElement.innerText.trim();
                const ddText = ddElement.innerText.trim();

                switch (dtText) {
                    case 'Cert #':
                        result.codigo = ddText;
                        break;
                    case 'Card Name':
                        result.nombre = ddText;
                        break;
                    // Añadir más casos según sea necesario para otras variables
                    default:
                        break;
                }
            }
        });

        // Obtener datos de div.related-info dentro de div.content-wrapper
        const relatedInfoElements = contentWrapper.querySelectorAll('div.related-info');

        relatedInfoElements.forEach(info => {
            const dlElements = info.querySelectorAll('dl');

            dlElements.forEach(dl => {
                const dtElement = dl.querySelector('dt');
                const ddElement = dl.querySelector('dd');
                if (dtElement && ddElement) {
                    const dtText = dtElement.innerText.trim();
                    const ddText = ddElement.innerText.trim();

                    switch (dtText) {
                        case 'Game':
                            result.coleccion = ddText;
                            break;
                        case 'Year':
                            result.anio = ddText;
                            break;
                        case 'Card Set':
                            result.edicion = ddText;
                            break;
                        case 'Card Number':
                            result.numero = ddText;
                            break;
                        default:
                            break;
                    }
                }
            });
        });

        // Obtener datos de div.related-info.grades.no-sub-grades dentro de div.content-wrapper
        const gradesInfo = contentWrapper.querySelector('div.related-info.grades.no-sub-grades dl');
        if (gradesInfo) {
            const dtElement = gradesInfo.querySelector('dt');
            const ddElement = gradesInfo.querySelector('dd');
            if (dtElement && ddElement) {
                const dtText = dtElement.innerText.trim();
                const ddText = ddElement.innerText.trim();

                if (dtText === 'Grade') {
                    result.gradeo = ddText;
                }
            }
        }

        return result;
    });

    // Agregar URL y empresa después de la evaluación
    data.url = page.url();
    let empresaLimpia = data.url.replace(/(https?:\/\/)?(www\.)?/, '');
    data.empresa = empresaLimpia.split('/')[0].replace(/\.com$/, '');

    return data;
}



async function getData(url) {
    const codigo = url.substring(url.lastIndexOf('/') + 1); // Extraer el código de la URL
    const browser = await puppeteer.launch({
        headless: true
    });

    try {
        const page = await browser.newPage();

        // Interceptar y bloquear solicitudes de imágenes
        await page.setRequestInterception(true);
        page.on('request', (request) => {
            if (request.resourceType() === 'image') {
                request.abort();
            } else {
                request.continue();
            }
        });

        // Navegar a la URL proporcionada
        await page.goto(url, { waitUntil: 'networkidle2' });

        // Esperar a que el usuario resuelva el CAPTCHA manualmente
        await waitForManualCaptchaSolution();

        // Obtener los datos de la página
        const data = await getPageData(page, codigo);

        // Imprimir los resultados
        console.log('Nombre:', data.nombre);
        console.log('Codigo:', data.codigo);
        console.log('Numero:', data.numero);
        console.log('Anio:', data.anio);
        console.log('Edicion:', data.edicion);
        console.log('Empresa:', data.empresa);
        console.log('Gradeo:', data.gradeo);
        console.log('Referencia:', data.url);

    } catch (error) {
        console.error('Error:', error);
    } finally {
        await browser.close();
    }
}

const url = 'https://www.cgggrade.com/cartes-cgg/' + process.argv[2];
// Llamar a la función getData con la URL deseada
getData(url);