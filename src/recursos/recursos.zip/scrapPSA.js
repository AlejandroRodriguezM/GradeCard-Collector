const puppeteer = require('puppeteer');

async function waitForManualCaptchaSolution() {
    // Espera 2 segundos para que el usuario resuelva el CAPTCHA manualmente (puedes ajustar este tiempo)
    await new Promise(resolve => setTimeout(resolve, 2000));
}

async function getPageData(page) {
    return page.evaluate(() => {
        const result = {
            url: window.location.href,
            empresa: '',
            direccionImagen: '',
            tabla: {},
        };

        const urlParts = window.location.href.split('.');
        if (urlParts.length > 2) {
            result.empresa = urlParts[1];
        }

        const imgElement = document.querySelector('img.img-responsive');
        if (imgElement) {
            result.direccionImagen = imgElement.src;
        }

        const tableRows = document.querySelectorAll('table.table.table-fixed.table-header-right.text-medium tr');
        tableRows.forEach(row => {
            const thElement = row.querySelector('th');
            const tdElement = row.querySelector('td');
            if (thElement && tdElement) {
                const key = thElement.textContent.trim();
                const value = tdElement.textContent.trim();
                result.tabla[key] = value;
            }
        });

        return result;
    });
}

function printData(data) {
    const {
        'Certification Number': certificationNumber = '',
        Year: year = '',
        Brand: originalBrand = '',
        'Card Number': cardNumber = '',
        Player: player = '',
        'Variety/Pedigree': varietyPedigree = '',
        Grade: grade = '',
    } = data.tabla;

    console.log('Nombre:', player);
    console.log('Codigo:', certificationNumber);
    console.log('Numero:', cardNumber);
    console.log('Anio:', year);
    console.log('Coleccion:', originalBrand);
    console.log('Edicion:', varietyPedigree);
    console.log('Empresa:', data.empresa);
    console.log('Gradeo:', grade);
    console.log('Dirección de Imagen:', data.direccionImagen);
    console.log('Referencia:', data.url);
}

async function getData(url) {
    const browser = await puppeteer.launch({
        headless: false,
        args: ['--window-size=10,10']
    });

    try {
        const page = await browser.newPage();

        // Interceptar y bloquear solicitudes de imágenes
        await page.setRequestInterception(true);
        page.on('request', (request) => {
            if (request.resourceType() === 'image') {
                request.abort();
            } else {
                request.continue();
            }
        });

        await page.goto(url, { waitUntil: 'networkidle2' });

        await waitForManualCaptchaSolution();

        const data = await getPageData(page);

        printData(data);
    } catch (error) {
        console.error('Error:', error);
    } finally {
        await browser.close();
    }
}

const url = "https://www.psacard.com/cert/" + process.argv[2];


getData(url);
