const puppeteer = require('puppeteer');

async function waitForManualCaptchaSolution() {
    // Espera 2 segundos para que el usuario resuelva el CAPTCHA manualmente (puedes ajustar este tiempo)
    await new Promise(resolve => setTimeout(resolve, 2000));
}

async function getPageData(page) {
    const data = await page.evaluate(() => {
        const result = {
            empresa: '',
            direccionImagen: '',
            tabla: {},
            gradeo: '',
            nombre: '',
            anio: '',
            edicion: '',
            numero: '',
            codigo: ''
        };

        // Extraer datos de h5 según la estructura específica
        const h5Elements = document.querySelectorAll('h5.font-bold.text-white.uppercase.px-6.text-sm');
        h5Elements.forEach((h5, index) => {
            const key = h5.innerText.trim();
            const valueElement = h5.nextElementSibling;
            const value = valueElement ? valueElement.innerText.trim() : "";
            result[key] = value;

            if (index === 4) {
                result.gradeo = `${key}${value}`;
            }
        });

        // Extraer el código de h3 específico
        const h3Element = document.querySelector('h3.text-7xl.font-display.font-bold.text-gold.text-center');
        result.codigo = h3Element ? h3Element.innerText.trim().replace(/#/, '') : '';

        // Buscar el contenedor específico
        const container = document.querySelector('div.lg\\:col-start-3.lg\\:row-end-1.rounded-md.bg-rich-black.shadow-lg');
        if (container) {
            // Buscar los divs que contienen pares dt-dd
            const divs = container.querySelectorAll('div.px-4.py-3');

            // Iterar sobre cada div encontrado
            divs.forEach(div => {
                const dt = div.querySelector('dt');
                const dd = div.querySelector('dd');

                if (dt && dd) {
                    const dtText = dt.innerText.trim();
                    const ddText = dd.innerText.trim();

                    // Verificar y asignar valores correspondientes según el dtText
                    if (dtText.toLowerCase().includes("name")) {
                        result.nombre = ddText;
                    } else if (dtText.toLowerCase().includes("release year")) {
                        result.anio = ddText;
                    } else if (dtText.toLowerCase().includes("set")) {
                        result.edicion = ddText;
                    } else if (dtText.toLowerCase().includes("number")) {
                        result.numero = ddText;
                    }
                }
            });
        }

        return result;
    });

    // Agregar URL y empresa después de la evaluación
    data.url = page.url();
    let empresaLimpia = data.url.replace(/(https?:\/\/)?(www\.)?/, '');
    data.empresa = empresaLimpia.split('/')[0].replace(/\.com$/, '');

    return data;
}


async function getData(url) {
    const browser = await puppeteer.launch({
        headless: false, // Cambiar a true para ejecutar en modo headless
        args: ['--window-size=10,10']
    });

    try {
        const page = await browser.newPage();

        // Interceptar y bloquear solicitudes de imágenes
        await page.setRequestInterception(true);
        page.on('request', (request) => {
            if (request.resourceType() === 'image') {
                request.abort();
            } else {
                request.continue();
            }
        });

        // Navegar a la URL proporcionada
        await page.goto(url, { waitUntil: 'networkidle2' });

        // Esperar a que el usuario resuelva el CAPTCHA manualmente
        await waitForManualCaptchaSolution();

        // Obtener los datos de la página
        const data = await getPageData(page);

        // Imprimir los resultados
        console.log('Nombre:', data.nombre);
        console.log('Codigo:', data.codigo);
        console.log('Numero:', data.numero);
        console.log('Anio:', data.anio);
        console.log('Edicion:', data.edicion);
        console.log('Empresa:', data.empresa);
        console.log('Gradeo:', data.gradeo);
        console.log('Referencia:', data.url);

    } catch (error) {
        console.error('Error:', error);
    } finally {
        await browser.close();
    }
}

const url = 'https://www.acegrading.com/cert/' + process.argv[2];
// Llamar a la función getData con la URL deseada
getData(url);
