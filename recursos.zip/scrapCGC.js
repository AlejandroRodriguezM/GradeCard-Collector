const puppeteer = require('puppeteer');

async function getData(url) {
    const browser = await puppeteer.launch({ headless: true }); // Cambia a false si deseas ver la navegación
    const page = await browser.newPage();

    try {
        await page.goto(url, { waitUntil: 'networkidle2' });

        const data = await page.evaluate((pageUrl) => {
            const result = {
                certNumber: '',
                cardName: '',
                game: '',
                year: '',
                cardSet: '',
                cardNumber: '',
                grade: '',
                imageUrl: '',
                referencia: pageUrl,
                empresa: pageUrl.replace(/(https?:\/\/)?(www\.)?/, '').split('/')[0].replace(/\.com$/, '')
            };

            const dlElements = document.querySelectorAll('dl');

            dlElements.forEach(dl => {
                const dtElement = dl.querySelector('dt');
                const ddElement = dl.querySelector('dd');

                if (dtElement && ddElement) {
                    const dtText = dtElement.innerText.trim();
                    const ddText = ddElement.innerText.trim();

                    switch (dtText) {
                        case 'Cert #':
                            result.certNumber = ddText;
                            break;
                        case 'Card Name':
                            result.cardName = ddText;
                            break;
                        case 'Game':
                            result.game = ddText;
                            break;
                        case 'Year':
                            result.year = ddText;
                            break;
                        case 'Card Set':
                            result.cardSet = ddText;
                            break;
                        case 'Card Number':
                            result.cardNumber = ddText;
                            break;
                        case 'Grade':
                            result.grade = ddText;
                            break;
                        default:
                            // Puedes manejar otros casos si es necesario
                            break;
                    }
                }
            });

            const imgElement = document.querySelector('img');
            result.imageUrl = imgElement ? imgElement.src : '';

            return result;
        }, page.url());

        printData(data);

    } catch (error) {
        console.error('Error:', error);

    } finally {
        await browser.close();
    }
}

function printData(data) {
    console.log('Nombre:', data.cardName);
    console.log('Codigo:', data.certNumber);
    console.log('Numero:', data.cardNumber);
    console.log('Anio:', data.year);
    console.log('Coleccion:', data.game);
    console.log('Edicion:', data.cardSet);
    console.log('Empresa:', data.empresa);
    console.log('Gradeo:', data.grade);
    console.log('Imagen:', data.imageUrl);
    console.log('Referencia:', data.referencia);
}

// URL de prueba
const url = 'https://www.cgccards.com/CERTLOOKUP/' + process.argv[2];

// Llamar a la función para obtener y mostrar los datos
getData(url);
