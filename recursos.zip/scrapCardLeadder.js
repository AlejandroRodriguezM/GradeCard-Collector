const puppeteer = require('puppeteer');

async function waitForManualCaptchaSolution() {
    // Espera 2 segundos para que el usuario resuelva el CAPTCHA manualmente
    await new Promise(resolve => setTimeout(resolve, 2000));
}

async function getData(url) {
    const browser = await puppeteer.launch({
        headless: false, // Cambiar a false para mostrar el navegador en acción
        args: ['--window-size=10,10'] // Ajusta el tamaño de la ventana según tus necesidades
    });

    const page = await browser.newPage();

    try {
        // Navega a la URL proporcionada
        await page.goto(url, { waitUntil: 'networkidle2' });

        // Espera la solución manual del CAPTCHA (simulado)
        await waitForManualCaptchaSolution();

        // Extraer datos de los enlaces
        const links = await page.$$eval('a.list-item.card-list-item.clickable.multi', anchors =>
            anchors.map(anchor => ({
                href: anchor.href.trim(),
                text: anchor.textContent.trim()
            }))
        );

        // Extraer datos de las estadísticas
        const stats = await page.$$eval('div.fields div.stat-item.regular', items =>
            items.map(item => {
                const label = item.querySelector('label').textContent.trim();
                const value = item.querySelector('div.value').textContent.trim();
                return { [label]: value };
            })
        );

        // Convertir stats a un objeto clave-valor plano
        const statsObject = stats.reduce((acc, obj) => {
            const key = Object.keys(obj)[0];
            acc[key] = obj[key];
            return acc;
        }, {});

        // Procesar el texto en clave-valor dentro de 'text'
        links.forEach(link => {
            // Aquí asumo que 'text' está en el formato proporcionado, adaptar según la estructura real
            const textParts = link.text.split(/\s{2,}/); // Dividir por dos o más espacios en blanco

            // Crear objeto para almacenar los datos procesados
            link.text = {};
            textParts.forEach(part => {
                const keyValue = part.split(/\s{1,}/); // Dividir por uno o más espacios en blanco
                if (keyValue.length === 2) {
                    const key = keyValue[0].trim();
                    const value = keyValue[1].trim();
                    link.text[key] = value;
                }
            });

            // Agregar los valores de las estadísticas al objeto 'text'
            Object.assign(link.text, statsObject);
        });

        // Agrupar enlaces por PSA
        const groupedByPSA = {};

        links.forEach(link => {
            const psaValue = link.text.PSA;
            if (!groupedByPSA[psaValue]) {
                groupedByPSA[psaValue] = [];
            }
            groupedByPSA[psaValue].push(link);
        });

        // Imprimir datos organizados por PSA
        Object.keys(groupedByPSA).forEach(psaValue => {
            console.log(`Enlaces con PSA ${psaValue}:`);
            groupedByPSA[psaValue].forEach(link => {
                console.log(`  Href: ${link.href}`);
                console.log(`  #1: ${link.text['#1']}`);
                console.log(`  No: ${link.text.No}`);
                console.log(`  PSA: ${link.text.PSA}`);
                console.log(`  Pop: ${link.text.Pop}`);
                console.log(`  Market Cap: ${link.text['Market Cap']}`);
                console.log(`  Last Sold: ${link.text['Last Sold']}`);
                console.log(); // Añade una línea en blanco entre cada enlace
            });
        });

    } catch (error) {
        console.error('Error:', error);
    } finally {
        // Cierra el navegador al finalizar
        await browser.close();
    }
}

// URL original
const baseUrl = "https://www.cardladder.com/search";

// Nuevo término de búsqueda
const newSearchTerm = "2009 POKEMON JAPANESE ARCEUS HOLO";

// Generar la nueva URL con el nuevo término de búsqueda
const urlToProcess = `${baseUrl}?q=${encodeURIComponent(newSearchTerm)}&t=ladder`;

console.log(urlToProcess)

// Procesar la URL
getData(urlToProcess);
