const puppeteer = require('puppeteer');

async function waitForManualCaptchaSolution() {
    // Espera 30 segundos para que el usuario resuelva el CAPTCHA manualmente (puedes ajustar este tiempo)
    await new Promise(resolve => setTimeout(resolve, 200));
}

async function getPageImageUrl(page) {
    return page.evaluate(() => {
        const imgElement = document.querySelector('img.img-responsive');
        return imgElement ? imgElement.src : '';
    });
}

async function getImage(url) {
    const browser = await puppeteer.launch({
        headless: false,
        args: ['--window-size=10,10']
    });

    try {
        const page = await browser.newPage();

        // Interceptar y bloquear solicitudes de imágenes innecesarias
        await page.setRequestInterception(true);
        page.on('request', (request) => {
            if (request.resourceType() === 'image' && !request.url().includes('img-responsive')) {
                request.abort();
            } else {
                request.continue();
            }
        });

        await page.goto(url, { waitUntil: 'networkidle2' });

        await waitForManualCaptchaSolution();

        const imageUrl = await getPageImageUrl(page);

        console.log(imageUrl);
    } catch (error) {
        console.error('Error:', error);
    } finally {
        await browser.close();
    }
}

const url = process.argv[2];

getImage(url);
