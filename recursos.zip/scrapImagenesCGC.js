const puppeteer = require('puppeteer');

async function getImageUrl(url) {
    const browser = await puppeteer.launch({ headless: true }); // Cambia a false si deseas ver la navegación
    const page = await browser.newPage();

    try {
        await page.goto(url, { waitUntil: 'networkidle2' });

        const imageUrl = await page.evaluate(() => {
            const imgElement = document.querySelector('img');
            return imgElement ? imgElement.src : '';
        });

        console.log('Imagen:', imageUrl);

    } catch (error) {
        console.error('Error:', error);

    } finally {
        await browser.close();
    }
}

// URL de prueba
const url = process.argv[2];

// Llamar a la función para obtener y mostrar la URL de la imagen
getImageUrl(url);
